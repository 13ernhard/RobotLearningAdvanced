Note that this folder only includes the files not provided in the given GitHub repository of Shail. 
Instructions how to use the provided Code is in the report.  


This readme file is only for the self programmed code for the DMP solver in main.py. 

---

## 🚀 Features

- Reads recorded robot trajectory data from CSV files
- Extracts 3D Cartesian positions (`x, y, z`)
- Trains a DMP model using the extracted trajectory
- Generates a new trajectory based on new start and goal positions
- Visualizes both the original and generated trajectories in 3D

## 🔧 Requirements

Install the required Python packages with:

```bash
pip install -r requirements.txt


## 🏃‍➡️ Run the Code

After installation you should change the 3 static object paths (PICK_OBJECT_PATH, HOME_OBJECT_PATH, PLACE_OBJECT_PATH) to the provided .csv files.

after that run main.py.
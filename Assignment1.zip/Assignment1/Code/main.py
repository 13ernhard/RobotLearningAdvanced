import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from movement_primitives.dmp import DMP

PICK_OBJECT_PATH = r"C:\Users\zornj\Desktop\TU_ES\4_Semester\WM_Robot_Learning\Task_1\arl_rosbag_files\arl2025\pick_object.csv"
HOME_OBJECT_PATH = r"C:\Users\zornj\Desktop\TU_ES\4_Semester\WM_Robot_Learning\Task_1\arl_rosbag_files\arl2025\pick_object.csv"
PLACE_OBJECT_PATH = r"C:\Users\zornj\Desktop\TU_ES\4_Semester\WM_Robot_Learning\Task_1\arl_rosbag_files\arl2025\place_object.csv"


def read_csv_files_cartesian(csv_path:str) -> tuple:
    """Reads in the csv file into a pandas DataFrame and extracts the cartesian coordinates
    
    Parameters
    ----------
    csv_path: str
        the path to the csv file

    Returns
    -------
    tuple:
        1. -> the DataFrame where csv file is read in
        2. -> numpy.ndarray: the numpy array of x,y,z coordinates -> shape: (num_of_frames, 3)
    """
    # read in the csv file into a DataFrame
    df = pd.read_csv(csv_path)

    # Extract Cartesian positions (x, y, z)
    positions = df[[
        'field.pose.position.x', 
        'field.pose.position.y', 
        'field.pose.position.z'
    ]].values

    return (df, positions)



def main() -> None:
    """The main function to call
    
    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    # define the path to the csv file of the movement
    movement_path = PICK_OBJECT_PATH  # TO MODIFY

    # Extract the cartesian coordinates
    dataframe, cartesian_coordinates_np = read_csv_files_cartesian(movement_path)

    # Set time array
    timesteps = np.linspace(0, 1, len(cartesian_coordinates_np))  # Normalize to [0, 1]

    ###### Train DMP #####
    # Create one DMP system per dimension (x, y, z)
    # Step 4: Train a single DMP for 3D Cartesian motion
    dmp = DMP(n_dims=3, execution_time=1.0, dt=timesteps[1] - timesteps[0], n_weights_per_dim=50)
    dmp.imitate(timesteps, cartesian_coordinates_np)

    # Step 5: Configure new start and goal positions
    new_start = np.array([0.1456, 0.001456, -0.1976])
    new_goal = np.array([0.2, 0.003455, 0.2456])
    dmp.configure(start_y=new_start, goal_y=new_goal)

    # Step 6: Generate the new trajectory
    T, Y = dmp.open_loop()

    # Step 7: Visualization
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111, projection='3d')

    # Original trajectory
    ax.plot(cartesian_coordinates_np[:, 0], cartesian_coordinates_np[:, 1], cartesian_coordinates_np[:, 2], label='Original Trajectory', color='blue')

    # New generated trajectory
    ax.plot(Y[:, 0], Y[:, 1], Y[:, 2], label='DMP Generated Trajectory', color='orange')

    ax.scatter(new_start[0], new_start[1], new_start[2], color='green', label='New Start')
    ax.scatter(new_goal[0], new_goal[1], new_goal[2], color='red', label='New Goal')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.legend()
    ax.set_title('Original vs DMP Generated Trajectory')
    plt.show()



    

if __name__ == "__main__":
    main()